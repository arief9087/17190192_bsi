<?php

class Mock_Database_DB_QueryBuilder extends CI_DB_query_builder {}