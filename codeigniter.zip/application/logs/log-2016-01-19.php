<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-19 00:45:20 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `cms_main_user` (`user_name`, `email`, `password`, `real_name`, `active`) VALUES ('rrrr', NULL, '73882ab1fa529d7273da0db6b49cc4f3', NULL, '1')
ERROR - 2016-01-19 00:45:42 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `cms_main_user` (`user_name`, `email`, `password`, `real_name`, `active`) VALUES ('rrrr', NULL, '73882ab1fa529d7273da0db6b49cc4f3', NULL, '1')
ERROR - 2016-01-19 10:07:02 --> Severity: Notice  --> Use of undefined constant Y - assumed 'Y' C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 333
ERROR - 2016-01-19 10:07:02 --> Severity: Notice  --> Use of undefined constant m - assumed 'm' C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 333
ERROR - 2016-01-19 10:07:02 --> Severity: Notice  --> Use of undefined constant d - assumed 'd' C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 333
ERROR - 2016-01-19 10:12:34 --> Severity: Notice  --> Undefined variable: date1 C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 348
ERROR - 2016-01-19 10:12:34 --> Severity: Notice  --> Undefined variable: date2 C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 348
ERROR - 2016-01-19 10:12:34 --> Severity: Warning  --> date_diff() expects parameter 1 to be DateTime, null given C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 348
ERROR - 2016-01-19 10:15:43 --> Query error: Unknown event 'ev_pangkat_28' - Invalid query: DROP EVENT ev_pangkat_28
ERROR - 2016-01-19 10:15:44 --> Query error: Unknown event 'ev_pangkat_27' - Invalid query: DROP EVENT ev_pangkat_27
ERROR - 2016-01-19 10:15:45 --> Query error: Unknown event 'ev_pangkat_26' - Invalid query: DROP EVENT ev_pangkat_26
ERROR - 2016-01-19 10:15:45 --> Query error: Unknown event 'ev_pangkat_25' - Invalid query: DROP EVENT ev_pangkat_25
ERROR - 2016-01-19 10:16:03 --> Query error: Unknown event 'ev_pangkat_21' - Invalid query: DROP EVENT ev_pangkat_21
ERROR - 2016-01-19 10:16:04 --> Query error: Unknown event 'ev_pangkat_22' - Invalid query: DROP EVENT ev_pangkat_22
ERROR - 2016-01-19 10:16:04 --> Query error: Unknown event 'ev_pangkat_23' - Invalid query: DROP EVENT ev_pangkat_23
ERROR - 2016-01-19 10:16:05 --> Query error: Unknown event 'ev_pangkat_24' - Invalid query: DROP EVENT ev_pangkat_24
ERROR - 2016-01-19 10:17:43 --> Query error: Unknown event 'ev_pangkat_18' - Invalid query: DROP EVENT ev_pangkat_18
ERROR - 2016-01-19 10:17:44 --> Query error: Unknown event 'ev_pangkat_19' - Invalid query: DROP EVENT ev_pangkat_19
ERROR - 2016-01-19 10:17:45 --> Query error: Unknown event 'ev_pangkat_20' - Invalid query: DROP EVENT ev_pangkat_20
ERROR - 2016-01-19 10:18:13 --> Query error: Unknown event 'ev_pangkat_17' - Invalid query: DROP EVENT ev_pangkat_17
ERROR - 2016-01-19 10:18:13 --> Query error: Unknown event 'ev_pangkat_16' - Invalid query: DROP EVENT ev_pangkat_16
ERROR - 2016-01-19 10:18:14 --> Query error: Unknown event 'ev_pangkat_15' - Invalid query: DROP EVENT ev_pangkat_15
ERROR - 2016-01-19 10:18:15 --> Query error: Unknown event 'ev_pangkat_14' - Invalid query: DROP EVENT ev_pangkat_14
ERROR - 2016-01-19 10:18:15 --> Query error: Unknown event 'ev_pangkat_12' - Invalid query: DROP EVENT ev_pangkat_12
ERROR - 2016-01-19 10:18:16 --> Query error: Unknown event 'ev_pangkat_11' - Invalid query: DROP EVENT ev_pangkat_11
ERROR - 2016-01-19 10:18:16 --> Query error: Unknown event 'ev_pangkat_13' - Invalid query: DROP EVENT ev_pangkat_13
ERROR - 2016-01-19 10:18:17 --> Query error: Unknown event 'ev_pangkat_10' - Invalid query: DROP EVENT ev_pangkat_10
ERROR - 2016-01-19 10:18:18 --> Query error: Unknown event 'ev_pangkat_9' - Invalid query: DROP EVENT ev_pangkat_9
ERROR - 2016-01-19 10:18:38 --> Query error: Unknown event 'ev_pangkat_8' - Invalid query: DROP EVENT ev_pangkat_8
ERROR - 2016-01-19 14:45:14 --> Severity: Notice  --> Undefined index: gaji C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 371
ERROR - 2016-01-19 14:45:14 --> Severity: Notice  --> Use of undefined constant Y - assumed 'Y' C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 376
ERROR - 2016-01-19 14:45:14 --> Severity: Notice  --> Use of undefined constant m - assumed 'm' C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 376
ERROR - 2016-01-19 14:45:14 --> Severity: Notice  --> Use of undefined constant d - assumed 'd' C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 376
ERROR - 2016-01-19 14:45:48 --> Severity: Notice  --> Undefined index: gaji C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 371
ERROR - 2016-01-19 14:45:48 --> Severity: Notice  --> Use of undefined constant Y - assumed 'Y' C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 376
ERROR - 2016-01-19 14:45:48 --> Severity: Notice  --> Use of undefined constant m - assumed 'm' C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 376
ERROR - 2016-01-19 14:45:48 --> Severity: Notice  --> Use of undefined constant d - assumed 'd' C:\xampp\htdocs\ci2_simpeg\modules\simpeg_stmik\controllers\manage_pegawai.php 376
ERROR - 2016-01-19 15:04:04 --> Query error: Unknown column 'tgl_mulai_kerja + INTERVAL 2 YEAR' in 'field list' - Invalid query: SELECT `nama_kar`, `tgl_mulai_kerja + INTERVAL 2 YEAR` AS `tanggal`
FROM `cms_sp_pegawai`
ORDER BY `tanggal` DESC
ERROR - 2016-01-19 16:05:45 --> Query error: Unknown column '$year' in 'field list' - Invalid query: SELECT `nama_kar`, (YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) = $year) AS tanggal
FROM `cms_sp_pegawai`
WHERE `tgl_mulai_kerja` >= '2016-01-12'
OR `tgl_mulai_kerja` <= '2016-01-19'
ORDER BY `tanggal` DESC
ERROR - 2016-01-19 16:11:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS tanggal END)
FROM `cms_sp_pegawai`
WHERE `tgl_mulai_kerja` >= '2016-01-12'
OR' at line 1 - Invalid query: SELECT `nama_kar`, (CASE WHEN (YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) = 2016) THEN (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal END)
FROM `cms_sp_pegawai`
WHERE `tgl_mulai_kerja` >= '2016-01-12'
OR `tgl_mulai_kerja` <= '2016-01-19'
ORDER BY `tanggal` DESC
ERROR - 2016-01-19 16:11:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS tanggal)
FROM `cms_sp_pegawai`
WHERE `tgl_mulai_kerja` >= '2016-01-12'
OR `tg' at line 1 - Invalid query: SELECT `nama_kar`, (CASE WHEN (YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) = 2016) THEN (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal)
FROM `cms_sp_pegawai`
WHERE `tgl_mulai_kerja` >= '2016-01-12'
OR `tgl_mulai_kerja` <= '2016-01-19'
ORDER BY `tanggal` DESC
ERROR - 2016-01-19 16:11:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS tanggal) END)
FROM `cms_sp_pegawai`
WHERE `tgl_mulai_kerja` >= '2016-01-12'
O' at line 1 - Invalid query: SELECT `nama_kar`, (CASE WHEN (YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) = 2016) THEN (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal) END)
FROM `cms_sp_pegawai`
WHERE `tgl_mulai_kerja` >= '2016-01-12'
OR `tgl_mulai_kerja` <= '2016-01-19'
ORDER BY `tanggal` DESC
ERROR - 2016-01-19 16:15:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS tanggal
FROM `cms_sp_pegawai`
WHERE YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) '' at line 1 - Invalid query: SELECT `nama_kar`, ((tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal
FROM `cms_sp_pegawai`
WHERE YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) '2016'
ORDER BY `tanggal` DESC
ERROR - 2016-01-19 16:15:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2016'
ORDER BY `tanggal` DESC' at line 3 - Invalid query: SELECT `nama_kar`, (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal
FROM `cms_sp_pegawai`
WHERE YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) '2016'
ORDER BY `tanggal` DESC
ERROR - 2016-01-19 16:17:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2016'
ORDER BY `tgl_mulai_kerja` DESC' at line 3 - Invalid query: SELECT `nama_kar`, (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal
FROM `cms_sp_pegawai`
WHERE YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) '2016'
ORDER BY `tgl_mulai_kerja` DESC
ERROR - 2016-01-19 16:18:29 --> Query error: Unknown column 'tanggal' in 'where clause' - Invalid query: SELECT `nama_kar`, (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal
FROM `cms_sp_pegawai`
WHERE YEAR(tanggal) = '2016'
ORDER BY `tgl_mulai_kerja` DESC
ERROR - 2016-01-19 16:18:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2016'
ORDER BY `tgl_mulai_kerja` DESC' at line 3 - Invalid query: SELECT `nama_kar`, (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal
FROM `cms_sp_pegawai`
WHERE YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) '2016'
ORDER BY `tgl_mulai_kerja` DESC
ERROR - 2016-01-19 16:19:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2016'
ORDER BY `tgl_mulai_kerja` DESC' at line 3 - Invalid query: SELECT `nama_kar`, (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal
FROM `cms_sp_pegawai`
WHERE YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) '2016'
ORDER BY `tgl_mulai_kerja` DESC
ERROR - 2016-01-19 16:20:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2016'
ORDER BY `tgl_mulai_kerja` DESC' at line 3 - Invalid query: SELECT `nama_kar`, (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal
FROM `cms_sp_pegawai`
WHERE (YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR)) '2016'
ORDER BY `tgl_mulai_kerja` DESC
ERROR - 2016-01-19 16:20:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''$year'
ORDER BY `tgl_mulai_kerja` DESC' at line 3 - Invalid query: SELECT `nama_kar`, (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal
FROM `cms_sp_pegawai`
WHERE YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) '$year'
ORDER BY `tgl_mulai_kerja` DESC
ERROR - 2016-01-19 16:20:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2016'
ORDER BY `tgl_mulai_kerja` DESC' at line 3 - Invalid query: SELECT `nama_kar`, (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal
FROM `cms_sp_pegawai`
WHERE YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) '2016'
ORDER BY `tgl_mulai_kerja` DESC
ERROR - 2016-01-19 16:21:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2016'
ORDER BY `tgl_mulai_kerja` DESC' at line 3 - Invalid query: SELECT `nama_kar`, (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal
FROM `cms_sp_pegawai`
WHERE YEARS(tgl_mulai_kerja + INTERVAL 2 YEAR) '2016'
ORDER BY `tgl_mulai_kerja` DESC
ERROR - 2016-01-19 16:21:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2016'
ORDER BY `tgl_mulai_kerja` DESC' at line 3 - Invalid query: SELECT `nama_kar`, (tgl_mulai_kerja + INTERVAL 2 YEAR) AS tanggal
FROM `cms_sp_pegawai`
WHERE YEAR(tgl_mulai_kerja + INTERVAL 2 YEAR) '2016'
ORDER BY `tgl_mulai_kerja` DESC
