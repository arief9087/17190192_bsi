<?php
class grocery_crud_model_MySQLi extends grocery_CRUD_Model{
	
}
